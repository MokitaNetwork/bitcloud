# Start template for web development
Using: `Gulp` + `Pug` + `SCSS (SASS)` + `Babel` + `BrowserSync`


## Install
How to start a project, see the instruction.html


## Available Scripts
In the project directory, you can run: `gulp`


## Contacts
